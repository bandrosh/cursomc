package br.com.saseducacao.sasoauth2api.authenticationapi.domain;

import org.springframework.security.core.SpringSecurityCoreVersion;

import java.io.Serializable;
import java.util.List;

public class User implements Serializable {
    private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

    private Long id;

    private String username;
    private String password;

    private String fullname;
    private List<String> profile;
    private boolean enabled;

    public User() {

    }

    public User(Long id, String username, String fullname, String password) {
        this.id = id;
        this.fullname = fullname;
        this.username = username;
        this.password = password;
    }

    public User(Long id, String username, String password, String fullname, List<String> profile, boolean enabled) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.profile = profile;
        this.enabled = enabled;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<String> getProfile() {
        return profile;
    }

    public void setProfile(List<String> profile) {
        this.profile = profile;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}

