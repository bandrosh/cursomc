package br.com.saseducacao.sasoauth2api.authenticationapi.repository;

import br.com.saseducacao.sasoauth2api.authenticationapi.domain.OauthUser;
import br.com.saseducacao.sasoauth2api.authenticationapi.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class UserRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private OauthUser getUser(List<Map<String, Object>> queryUser) {
        List<String> listProfile = new ArrayList<>();
        for (Map<String, Object> profile : queryUser) {
            listProfile.add((String) profile.get("ds_perfil"));
        }

        if (queryUser.isEmpty()) {
            return null;
        }

        User user = new User(
                (Long) queryUser.get(0).get("id_usuario"),
                (String) queryUser.get(0).get("ds_login"),
                (String) queryUser.get(0).get("nm_usuario"),
                (String) queryUser.get(0).get("ds_senha")
        );
        user.setProfile(listProfile);
        user.setEnabled(true);
        return new OauthUser(user);
    }

    public OauthUser findOneByUsername(String username, Integer year) {
        String sql =
                "select u.id_usuario, u.ds_login, u.ds_senha, u.nm_usuario, p.ds_perfil " +
                        "from sgl_usuario u " +
                        "join sgl_usuario_perfil_pessoa upp on upp.id_usuario = u.id_usuario " +
                        "join sgl_pessoa_periodo_letivo ppl on upp.id_pessoa = ppl.id_pessoa " +
                        "join sgl_escola_estrutura ee on ppl.id_escola_estrutura = ee.id_escola_estrutura " +
                        "join sgl_perfil p on upp.id_perfil = p.id_perfil " +
                        "where ppl.nr_ano = ? and ds_login = ? and u.fl_ativo = true and ppl.sn_ativo = true and upp.sn_ativo = true and ee.sn_ativo = true " +
                        "group by u.id_usuario, u.ds_login, u.ds_senha, u.nm_usuario, p.ds_perfil";

        Object[] parameters = new Object[]{year, username};

        List<Map<String, Object>> queryUser = jdbcTemplate.queryForList(sql, parameters);

        return getUser(queryUser);
    }
}
