package br.com.saseducacao.sasoauth2api.authenticationapi.service;

import br.com.saseducacao.sasoauth2api.authenticationapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Calendar;

@Service("userDetailsService")
public class UserService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    private Integer getYear() {
        return Calendar.getInstance().get(Calendar.YEAR);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDetails userDetails = userRepository.findOneByUsername(username, getYear());

        if(userDetails == null){
            throw new UsernameNotFoundException("User "+ username +" not found!");
        }

        return userDetails;
    }
}
