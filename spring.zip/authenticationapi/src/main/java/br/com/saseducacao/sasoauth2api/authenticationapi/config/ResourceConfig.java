package br.com.saseducacao.sasoauth2api.authenticationapi.config;

import br.com.saseducacao.sasoauth2api.authenticationapi.oauth.SaltedMd5PasswordEncoder;
import br.com.saseducacao.sasoauth2api.authenticationapi.oauth.UserDetailsAuthenticationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@Configuration
@EnableResourceServer
public class ResourceConfig {
    @Autowired
    @Qualifier("userDetailsService")
    private UserDetailsService userDetailsService;

    @Autowired
    private SaltedMd5PasswordEncoder passwordEncoder;

    @Autowired
    public void configureGlobal(final AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authProvider()).userDetailsService(userDetailsService).passwordEncoder(passwordEncoder);
    }

    public AuthenticationProvider authProvider() {
        UserDetailsAuthenticationProvider provider
                = new UserDetailsAuthenticationProvider(passwordEncoder, userDetailsService);
        return provider;
    }

}
