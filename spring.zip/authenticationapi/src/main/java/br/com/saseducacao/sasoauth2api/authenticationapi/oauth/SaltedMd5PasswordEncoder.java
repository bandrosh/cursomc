package br.com.saseducacao.sasoauth2api.authenticationapi.oauth;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

@Service
public class SaltedMd5PasswordEncoder implements PasswordEncoder {

    @Override
    public String encode(CharSequence plain) {
        Assert.notNull(plain,"plain should not be null");
        Assert.hasText(plain.toString(),"plain should not be null");
        return DigestUtils.md5Hex(plain.toString());
    }

    @Override
    public boolean matches(CharSequence plain, String encoded) {

        if(plain != null && encoded != null){
            String[] parts = encoded.split(":");
            String hashPassword = parts[0];
            String salt = "";

            if (parts.length > 1) {
                salt = parts[1];
            }

            String raw = plain.toString().concat(salt);
            String passEncoded = encode(raw);

            return passEncoded.equalsIgnoreCase(hashPassword);
        }

        return false;
    }
}
