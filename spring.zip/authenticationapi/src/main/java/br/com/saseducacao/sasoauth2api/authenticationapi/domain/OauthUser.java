package br.com.saseducacao.sasoauth2api.authenticationapi.domain;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class OauthUser implements UserDetails {
    private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

    private User user;

    public OauthUser() {
    }

    public OauthUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public Long getId(){
        return user.getId();
    }

    public String getFullname() {
        return user.getFullname();
    }

    public List<String> getProfile(){
        return user.getProfile();
    }

    @Override
    public boolean isEnabled() {
        return user.isEnabled();
    }


    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<>();

        return authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
}