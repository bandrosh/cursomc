package br.com.saseducacao.sasoauth2api.authenticationapi.controller;

import br.com.saseducacao.sasoauth2api.authenticationapi.domain.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {

    @RequestMapping("/")
    public String home(){
        return "Hello World";
    }

    private User getLoggingUser(SecurityContext context) {

        Authentication authentication = context.getAuthentication();

        if (authentication != null) {

            UserDetails userPrincipal = (UserDetails) authentication.getPrincipal();
            ModelMapper dataMapper = new ModelMapper();
            User user = dataMapper.map(userPrincipal, User.class);

            return user;
        }
        return null;
    }

    @RequestMapping(value = "/me", method = RequestMethod.GET)
    public ResponseEntity<?> getLoggedUser(HttpServletRequest request) {

        SecurityContext context = SecurityContextHolder.getContext();
        User user = getLoggingUser(context);

        ObjectMapper jsonMapper = new ObjectMapper();
        Map<String, Object> json = jsonMapper.convertValue(user, Map.class);

        if (user != null) {
            return new ResponseEntity<>(json, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}